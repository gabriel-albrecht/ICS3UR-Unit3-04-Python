#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This program identifies if the number is positive, negative or 0


def main():
    # input
    integer = int(input("Enter a number: "))

    if integer < 0:
        print("")
        print("This is a negative integer.")
    elif integer > 0:
        print("")
        print("This is a positive integer.")
    else:
        print("")
        print("This is zero.")


if __name__ == "__main__":
    main()
